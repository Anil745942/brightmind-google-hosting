
FREE APP

Created by WebIntoApp.com on Sunday 14th of June 2026 12:33:48 PM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			1420293
App Key:		LwAnTeIYUnMBodfHSIxMuorJfpsxBMNd
App Name:		Bright Mind
App Version:	1.0
Package:		com.mycompany.brightmind
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://webintoapp.com/author/apps/1420293/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://webintoapp.com/author/apps

Get installs statistics at:
https://webintoapp.com/author/stats?appid=1420293

The Author Area:
https://webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
