
FREE APP

Created by WebIntoApp.com on Monday 29th of June 2026 05:34:15 PM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			1457495
App Key:		QUFBhLnJJVgbcRHuiBLyPPMBOXyVpmVz
App Name:		Gyanology
App Version:	1.0
Package:		com.arpitdev.gyanology
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://webintoapp.com/author/apps/1457495/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://webintoapp.com/author/apps

Get installs statistics at:
https://webintoapp.com/author/stats?appid=1457495

The Author Area:
https://webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
